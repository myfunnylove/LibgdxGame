---------------------------------------------
Kushha license terms
---------------------------------------------

* All our resources are royalty free for use in both personal and commercial projects.

* You can modify any resources to your liking to fit into your project, we are however not legally liable for any misuse of our resources

* You cannot however redistribute, resell, lease, license, sub-license or offer our resources to any third party. This includes uploading our resources to another website or media-sharing tool, and offering our resources as a separate attachment from any of your work. 

http://dribbble.com/kushha
